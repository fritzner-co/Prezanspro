# PrésencePro — Build APK sou telefòn sèlman

Pwojè sa a prepare pou GitHub Actions. GitHub ap fè konpilasyon Flutter/Android la sou yon machin cloud; telefòn ou pa bezwen gen Android Studio.

## Sa ki deja prepare
- `.github/workflows/android-apk.yml`
- Kamera + entènèt nan AndroidManifest
- Build release APK
- Upload APK kòm artifact
- Supabase URL/anon key pase kòm GitHub Secrets, pa nan kòd la

## Sa ou bezwen fè sou telefòn
1. Kreye oswa konekte yon kont GitHub.
2. Kreye yon nouvo repository, pa egzanp `presencepro`.
3. Upload tout fichye pwojè sa a nan repository a (ZIP la dwe dekonprese nan repo a).
4. Ale nan Settings > Secrets and variables > Actions.
5. Ajoute:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
6. Ale nan Actions > `Build PrésencePro APK` > Run workflow.
7. Lè workflow la fini, louvri run nan epi telechaje artifact `presencepro-release-apk`.
8. Dekonprese artifact la; APK a rele `app-release.apk`.
9. Tape APK a sou Android pou enstale li.

## Enpòtan
Pou yon APK final ki ka itilize pa lòt moun, nou dwe fè release signing/keystore. Pou yon premye APK tès, workflow sa a ase.

## Sekirite
Pa mete `service_role`/secret Supabase key nan aplikasyon Android la. Sèvi ak anon/publishable key + RLS.
