# PrésencePro — Etap pou fè vèsyon Cloud la mache

Mwen prepare kòd aplikasyon an ak koneksyon Supabase. Gen 2 bagay ki dwe fèt sou kont ou paske se ou menm ki dwe posede sèvis yo:

## 1) Kreye pwojè Supabase
- Kreye yon pwojè sou Supabase.
- Louvri SQL Editor.
- Kole tout `supabase_schema.sql` epi kouri li.
- Kreye premye itilizatè administratè nan Authentication > Users.
- Kreye yon òganizasyon nan Table Editor > organizations epi note UUID li.

## 2) Mete credentials yo nan aplikasyon an
Kouri Flutter ak:
`flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY`

Pa mete `service_role` key nan aplikasyon Android la. Se `anon/publishable` key ki fèt pou client la, ansanm ak RLS.

## 3) Mete organization UUID la
Nan `lib/screens/people_screen.dart`, ranplase:
`PUT_ORGANIZATION_UUID_HERE`
ak UUID òganizasyon ou kreye a.

## 4) Kamera Android
Nan `android/app/src/main/AndroidManifest.xml`, verifye:
`<uses-permission android:name="android.permission.CAMERA" />`

## 5) Konpile
`flutter pub get`
`flutter run`
Pou APK:
`flutter build apk --release`

## Sa MVP cloud la deja fè
- Login Supabase Auth
- Lekti/ajoute moun nan cloud
- QR token + QR card
- Scan QR
- Check-in premye scan nan jounen an
- Check-out dezyèm scan
- Tab attendance nan PostgreSQL
- RLS aktive sou tab cloud yo

## Sa ki rete pou production
- Ranplase policies dev yo ak RLS ki baze sou membership/role
- Offline queue + sync
- Dashboard reyèl ak queries
- Rapò PDF/Excel
- Enprime kat an pakèt
- Department relational table
- Work schedule ak kalkil late
- Admin roles
- Audit logs
- Backup/monitoring
